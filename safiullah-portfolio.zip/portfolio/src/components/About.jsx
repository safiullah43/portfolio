import { motion } from 'framer-motion'
import { MapPin, GraduationCap, ShieldCheck } from 'lucide-react'
import SectionHeading from './SectionHeading'
import Counter from './Counter'
import { profile, stats } from '../utils/data'
import { fadeUp, staggerContainer } from '../utils/motionVariants'
import { useInView } from '../hooks/useInView'

const specializations = [
  'Amazon FBA', 'Private Label', 'Wholesale', 'Online Arbitrage',
  'Dropshipping', '3PL', 'Supplier Sourcing', 'Product Research',
  'Inventory Management', 'Product Listings', 'Shopify Management',
]

export default function About() {
  const [ref, isInView] = useInView({ threshold: 0.15 })

  return (
    <section id="about" className="relative py-28">
      <div className="section-container">
        <SectionHeading eyebrow="Get To Know Me" title="About Me" />

        <div className="grid gap-14 lg:grid-cols-2 lg:items-start">
          <motion.div
            ref={ref}
            variants={staggerContainer}
            initial="hidden"
            animate={isInView ? 'visible' : 'hidden'}
          >
            <motion.div custom={0} variants={fadeUp} className="glass-card p-6 sm:p-8">
              <div className="flex flex-wrap items-center gap-4 border-b border-white/10 pb-5">
                <div>
                  <p className="font-display text-lg font-semibold text-[var(--color-white)]">
                    {profile.name}
                  </p>
                  <p className="flex items-center gap-1.5 text-sm text-[var(--color-gray)]">
                    <MapPin size={14} className="text-[var(--color-gold-accent)]" /> {profile.country}
                  </p>
                </div>
              </div>

              <p className="mt-6 text-sm leading-relaxed text-[var(--color-gray)] sm:text-base">
                {profile.summary}
              </p>

              <div className="mt-6 flex flex-col gap-3 text-sm text-[var(--color-gray)] sm:flex-row sm:gap-8">
                <span className="flex items-center gap-2">
                  <GraduationCap size={16} className="text-[var(--color-gold-accent)]" />
                  BSCS — Currently Enrolled
                </span>
                <span className="flex items-center gap-2">
                  <ShieldCheck size={16} className="text-[var(--color-gold-accent)]" />
                  Cyber Security Diploma
                </span>
              </div>
            </motion.div>

            <motion.div custom={1} variants={fadeUp} className="mt-6 flex flex-wrap gap-2.5">
              {specializations.map((tag) => (
                <span
                  key={tag}
                  className="rounded-full border border-[#d4af37]/25 bg-white/[0.03] px-4 py-1.5 text-xs font-medium text-[var(--color-gray)] transition-colors hover:border-[#d4af37]/60 hover:text-[var(--color-gold-accent)]"
                >
                  {tag}
                </span>
              ))}
            </motion.div>
          </motion.div>

          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate={isInView ? 'visible' : 'hidden'}
            className="grid grid-cols-2 gap-5"
          >
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                custom={i}
                variants={fadeUp}
                className="glass-card flex flex-col items-center justify-center gap-2 p-8 text-center"
              >
                <Counter value={stat.value} suffix={stat.suffix} />
                <p className="text-xs uppercase tracking-wide text-[var(--color-gray)]">
                  {stat.label}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}
