import { motion } from 'framer-motion'
import { Trophy } from 'lucide-react'
import SectionHeading from './SectionHeading'
import { achievements } from '../utils/data'
import { fadeUp, staggerContainer } from '../utils/motionVariants'
import { useInView } from '../hooks/useInView'

export default function Achievements() {
  const [ref, isInView] = useInView({ threshold: 0.15 })

  return (
    <section id="achievements" className="relative py-28">
      <div className="section-container">
        <SectionHeading eyebrow="Milestones" title="Achievements" />

        <motion.div
          ref={ref}
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4"
        >
          {achievements.map((item, i) => (
            <motion.div
              key={item.title}
              custom={i}
              variants={fadeUp}
              className="glass-card flex flex-col items-center gap-4 p-7 text-center"
            >
              <div className="grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-[#f5c542]/20 to-[#d4af37]/10 text-[var(--color-gold-accent)]">
                <Trophy size={20} />
              </div>
              <p className="font-display text-sm font-semibold text-[var(--color-white)]">
                {item.title}
              </p>
              <p className="text-xs leading-relaxed text-[var(--color-gray)]">
                {item.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
