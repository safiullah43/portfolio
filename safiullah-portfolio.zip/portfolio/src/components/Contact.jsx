import { useState } from 'react'
import { motion } from 'framer-motion'
import { Mail, Linkedin, Github, MessageCircle, MapPin, Send } from 'lucide-react'
import SectionHeading from './SectionHeading'
import { contact } from '../utils/data'
import { fadeUp, staggerContainer } from '../utils/motionVariants'
import { useInView } from '../hooks/useInView'

const contactLinks = [
  { icon: Mail, label: 'Email', value: contact.email, href: `mailto:${contact.email}` },
  { icon: Linkedin, label: 'LinkedIn', value: 'Connect on LinkedIn', href: contact.linkedin },
  { icon: Github, label: 'GitHub', value: 'View my repos', href: contact.github },
  { icon: MessageCircle, label: 'WhatsApp', value: 'Chat directly', href: contact.whatsapp },
]

export default function Contact() {
  const [ref, isInView] = useInView({ threshold: 0.1 })
  const [status, setStatus] = useState('idle')
  const [form, setForm] = useState({ name: '', email: '', message: '' })

  function handleChange(e) {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }))
  }

  function handleSubmit(e) {
    e.preventDefault()
    // Wire this up to your form backend of choice (Formspree, EmailJS, etc.)
    setStatus('sent')
    setTimeout(() => setStatus('idle'), 3500)
    setForm({ name: '', email: '', message: '' })
  }

  return (
    <section id="contact" className="relative py-28">
      <div className="section-container">
        <SectionHeading
          eyebrow="Let's Work Together"
          title="Get In Touch"
          description="Have a project, a store that needs help, or just want to say hello? My inbox is open."
        />

        <div ref={ref} className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr]">
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate={isInView ? 'visible' : 'hidden'}
            className="flex flex-col gap-4"
          >
            {contactLinks.map((link, i) => (
              <motion.a
                key={link.label}
                custom={i}
                variants={fadeUp}
                href={link.href}
                target={link.href.startsWith('http') ? '_blank' : undefined}
                rel="noreferrer"
                className="glass-card flex items-center gap-4 p-5"
              >
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[#f5c542]/20 to-[#d4af37]/10 text-[var(--color-gold-accent)]">
                  <link.icon size={18} />
                </div>
                <div>
                  <p className="text-xs uppercase tracking-wide text-[var(--color-gray)]">{link.label}</p>
                  <p className="text-sm font-medium text-[var(--color-white)]">{link.value}</p>
                </div>
              </motion.a>
            ))}

            <motion.div custom={4} variants={fadeUp} className="glass-card flex items-center gap-4 p-5">
              <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[#f5c542]/20 to-[#d4af37]/10 text-[var(--color-gold-accent)]">
                <MapPin size={18} />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wide text-[var(--color-gray)]">Location</p>
                <p className="text-sm font-medium text-[var(--color-white)]">{contact.location}</p>
              </div>
            </motion.div>
          </motion.div>

          <motion.form
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: isInView ? 1 : 0, y: isInView ? 0 : 30 }}
            transition={{ duration: 0.6 }}
            onSubmit={handleSubmit}
            className="glass-card flex flex-col gap-5 p-7 sm:p-9"
          >
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label htmlFor="name" className="mb-2 block text-xs uppercase tracking-wide text-[var(--color-gray)]">
                  Name
                </label>
                <input
                  id="name"
                  name="name"
                  required
                  value={form.name}
                  onChange={handleChange}
                  placeholder="Your name"
                  className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-[var(--color-white)] outline-none transition-colors placeholder:text-[var(--color-gray)] focus:border-[#d4af37]"
                />
              </div>
              <div>
                <label htmlFor="email" className="mb-2 block text-xs uppercase tracking-wide text-[var(--color-gray)]">
                  Email
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={form.email}
                  onChange={handleChange}
                  placeholder="you@example.com"
                  className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-[var(--color-white)] outline-none transition-colors placeholder:text-[var(--color-gray)] focus:border-[#d4af37]"
                />
              </div>
            </div>

            <div>
              <label htmlFor="message" className="mb-2 block text-xs uppercase tracking-wide text-[var(--color-gray)]">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                required
                rows={5}
                value={form.message}
                onChange={handleChange}
                placeholder="Tell me about your project..."
                className="w-full resize-none rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-[var(--color-white)] outline-none transition-colors placeholder:text-[var(--color-gray)] focus:border-[#d4af37]"
              />
            </div>

            <button type="submit" className="btn-gold w-fit">
              <Send size={16} /> {status === 'sent' ? 'Message Sent!' : 'Send Message'}
            </button>
          </motion.form>
        </div>
      </div>
    </section>
  )
}
