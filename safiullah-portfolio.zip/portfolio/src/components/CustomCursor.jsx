import { useEffect, useRef } from 'react'
import { useMousePosition } from '../hooks/useMousePosition'

/** Renders a gold dot + delayed ring that follow the pointer on desktop. */
export default function CustomCursor() {
  const { x, y } = useMousePosition()
  const ringRef = useRef(null)
  const dotRef = useRef(null)
  const ringPos = useRef({ x, y })

  useEffect(() => {
    let frame
    const animate = () => {
      ringPos.current.x += (x - ringPos.current.x) * 0.15
      ringPos.current.y += (y - ringPos.current.y) * 0.15
      if (ringRef.current) {
        ringRef.current.style.transform = `translate(${ringPos.current.x}px, ${ringPos.current.y}px) translate(-50%, -50%)`
      }
      if (dotRef.current) {
        dotRef.current.style.transform = `translate(${x}px, ${y}px) translate(-50%, -50%)`
      }
      frame = requestAnimationFrame(animate)
    }
    frame = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(frame)
  }, [x, y])

  useEffect(() => {
    document.documentElement.style.setProperty('--x', `${x}px`)
    document.documentElement.style.setProperty('--y', `${y}px`)
  }, [x, y])

  return (
    <>
      <div className="mouse-glow hidden md:block" />
      <div ref={dotRef} className="cursor-dot" />
      <div ref={ringRef} className="cursor-ring" />
    </>
  )
}
