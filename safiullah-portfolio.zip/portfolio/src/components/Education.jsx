import { motion } from 'framer-motion'
import { GraduationCap, BadgeCheck, Clock } from 'lucide-react'
import SectionHeading from './SectionHeading'
import { education, certifications } from '../utils/data'
import { fadeUp, staggerContainer } from '../utils/motionVariants'
import { useInView } from '../hooks/useInView'

export default function Education() {
  const [ref, isInView] = useInView({ threshold: 0.1 })

  return (
    <section id="education" className="relative py-28">
      <div className="section-container">
        <SectionHeading eyebrow="Learning Never Stops" title="Education & Certifications" />

        <div ref={ref} className="grid gap-10 lg:grid-cols-2">
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate={isInView ? 'visible' : 'hidden'}
            className="flex flex-col gap-5"
          >
            <motion.h3 custom={0} variants={fadeUp} className="font-display text-lg font-semibold text-[var(--color-gold-accent)]">
              Education
            </motion.h3>
            {education.map((item, i) => (
              <motion.div key={item.title} custom={i + 1} variants={fadeUp} className="glass-card flex items-start gap-4 p-6">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[#f5c542]/20 to-[#d4af37]/10 text-[var(--color-gold-accent)]">
                  <GraduationCap size={20} />
                </div>
                <div>
                  <p className="font-medium text-[var(--color-white)]">{item.title}</p>
                  <p className="mt-1 flex items-center gap-1.5 text-sm text-[var(--color-gray)]">
                    <Clock size={13} /> {item.status}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate={isInView ? 'visible' : 'hidden'}
            className="flex flex-col gap-5"
          >
            <motion.h3 custom={0} variants={fadeUp} className="font-display text-lg font-semibold text-[var(--color-gold-accent)]">
              Certifications
            </motion.h3>
            <div className="grid gap-4 sm:grid-cols-2">
              {certifications.map((cert, i) => (
                <motion.div
                  key={cert.title + i}
                  custom={i + 1}
                  variants={fadeUp}
                  className={`glass-card flex items-start gap-3 p-5 ${cert.placeholder ? 'opacity-50' : ''}`}
                >
                  <BadgeCheck size={18} className="mt-0.5 shrink-0 text-[var(--color-gold-accent)]" />
                  <div>
                    <p className="text-sm font-medium text-[var(--color-white)]">{cert.title}</p>
                    <p className="mt-0.5 text-xs text-[var(--color-gray)]">{cert.issuer} · {cert.year}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
