import { motion } from 'framer-motion'
import { Briefcase, CheckCircle2 } from 'lucide-react'
import SectionHeading from './SectionHeading'
import { experience } from '../utils/data'
import { fadeUp, slideInLeft, staggerContainer } from '../utils/motionVariants'
import { useInView } from '../hooks/useInView'

export default function Experience() {
  const [ref, isInView] = useInView({ threshold: 0.1 })

  return (
    <section id="experience" className="relative py-28">
      <div className="section-container">
        <SectionHeading eyebrow="My Journey" title="Experience" />

        <div ref={ref} className="relative mx-auto max-w-3xl">
          <div className="absolute left-[19px] top-2 bottom-2 w-px bg-gradient-to-b from-[#d4af37]/60 via-[#d4af37]/20 to-transparent sm:left-1/2" />

          {experience.map((job, i) => (
            <motion.div
              key={job.role}
              custom={i}
              variants={slideInLeft}
              initial="hidden"
              animate={isInView ? 'visible' : 'hidden'}
              className="relative mb-10 flex gap-6 sm:mb-0 sm:justify-center sm:py-10"
            >
              <div className="relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-[#d4af37]/50 bg-[var(--color-bg)] text-[var(--color-gold-accent)] sm:absolute sm:left-1/2 sm:-translate-x-1/2">
                <Briefcase size={16} />
              </div>

              <motion.div
                variants={staggerContainer}
                initial="hidden"
                animate={isInView ? 'visible' : 'hidden'}
                className="glass-card w-full p-6 sm:mr-auto sm:w-[calc(50%-3rem)] sm:mt-0"
              >
                <motion.p custom={0} variants={fadeUp} className="text-xs uppercase tracking-wide text-[var(--color-gold-accent)]">
                  {job.period}
                </motion.p>
                <motion.h3 custom={1} variants={fadeUp} className="mt-1 font-display text-xl font-semibold text-[var(--color-white)]">
                  {job.role}
                </motion.h3>
                <motion.ul custom={2} variants={fadeUp} className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-sm text-[var(--color-gray)]">
                  {job.points.map((point) => (
                    <li key={point} className="flex items-center gap-2">
                      <CheckCircle2 size={14} className="shrink-0 text-[var(--color-gold-accent)]" />
                      {point}
                    </li>
                  ))}
                </motion.ul>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
