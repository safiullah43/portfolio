import { motion } from 'framer-motion'
import { Mail, Linkedin, Github, MessageCircle, ArrowUp } from 'lucide-react'
import { navLinks, contact, profile } from '../utils/data'

const socials = [
  { icon: Mail, href: `mailto:${contact.email}` },
  { icon: Linkedin, href: contact.linkedin },
  { icon: Github, href: contact.github },
  { icon: MessageCircle, href: contact.whatsapp },
]

export default function Footer() {
  function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <footer className="relative border-t border-white/5 bg-[var(--color-bg-secondary)] pt-16 pb-8">
      <div className="section-container">
        <div className="grid gap-10 sm:grid-cols-3">
          <div>
            <p className="font-display text-xl font-bold">
              <span className="gold-gradient-text">{profile.name.charAt(0)}</span>
              <span>afiullah</span>
            </p>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-[var(--color-gray)]">
              Amazon Virtual Assistant & E-Commerce Specialist helping brands grow — based in {profile.country}.
            </p>
          </div>

          <div>
            <p className="mb-4 text-xs uppercase tracking-[0.3em] text-[var(--color-gold-accent)]">
              Navigate
            </p>
            <ul className="flex flex-col gap-2.5">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault()
                      document.querySelector(link.href)?.scrollIntoView({ behavior: 'smooth' })
                    }}
                    className="text-sm text-[var(--color-gray)] transition-colors hover:text-[var(--color-gold-accent)]"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="mb-4 text-xs uppercase tracking-[0.3em] text-[var(--color-gold-accent)]">
              Connect
            </p>
            <div className="flex gap-3">
              {socials.map(({ icon: Icon, href }, i) => (
                <a
                  key={i}
                  href={href}
                  target={href.startsWith('http') ? '_blank' : undefined}
                  rel="noreferrer"
                  className="grid h-10 w-10 place-items-center rounded-full border border-white/10 text-[var(--color-gray)] transition-colors hover:border-[#d4af37] hover:text-[var(--color-gold-accent)]"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/5 pt-6 sm:flex-row">
          <p className="text-xs text-[var(--color-gray)]">
            © {new Date().getFullYear()} {profile.name}. All rights reserved.
          </p>
          <motion.button
            onClick={scrollToTop}
            whileHover={{ y: -3 }}
            className="grid h-9 w-9 place-items-center rounded-full border border-white/10 text-[var(--color-gold-accent)]"
            aria-label="Back to top"
          >
            <ArrowUp size={15} />
          </motion.button>
        </div>
      </div>
    </footer>
  )
}
