import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import gsap from 'gsap'
import { ArrowDown, Download, Mail, FolderKanban } from 'lucide-react'
import ParticlesBackground from './ParticlesBackground'
import { profile } from '../utils/data'

function useTypingEffect(words, { typingSpeed = 90, deletingSpeed = 45, pause = 1400 } = {}) {
  const [text, setText] = useState('')
  const [wordIndex, setWordIndex] = useState(0)
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    const currentWord = words[wordIndex % words.length]
    let timeout

    if (!isDeleting && text === currentWord) {
      timeout = setTimeout(() => setIsDeleting(true), pause)
    } else if (isDeleting && text === '') {
      setIsDeleting(false)
      setWordIndex((i) => i + 1)
    } else {
      timeout = setTimeout(() => {
        setText((prev) =>
          isDeleting ? prev.slice(0, -1) : currentWord.slice(0, prev.length + 1)
        )
      }, isDeleting ? deletingSpeed : typingSpeed)
    }

    return () => clearTimeout(timeout)
  }, [text, isDeleting, wordIndex, words, typingSpeed, deletingSpeed, pause])

  return text
}

export default function Hero() {
  const typedRole = useTypingEffect(profile.roles)
  const headlineRef = useRef(null)

  useEffect(() => {
    if (!headlineRef.current) return
    const letters = headlineRef.current.querySelectorAll('.hero-letter')
    gsap.fromTo(
      letters,
      { y: 60, opacity: 0, rotateX: -40 },
      { y: 0, opacity: 1, rotateX: 0, duration: 0.9, ease: 'power4.out', stagger: 0.045, delay: 0.2 }
    )
  }, [])

  const name = profile.name.split('')

  return (
    <section id="home" className="relative flex min-h-screen items-center overflow-hidden pt-28">
      <div className="absolute inset-0">
        <ParticlesBackground density={70} />
        <div className="absolute -top-40 left-1/2 h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-[#d4af37]/10 blur-[140px]" />
        <div className="absolute bottom-0 right-0 h-[400px] w-[400px] rounded-full bg-[#f5c542]/10 blur-[130px]" />
      </div>

      <div className="section-container relative z-10 grid items-center gap-12 lg:grid-cols-[1.15fr_0.85fr]">
        <div>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="section-eyebrow mb-5"
          >
            Welcome to my portfolio
          </motion.p>

          <h1
            ref={headlineRef}
            className="font-display text-5xl font-extrabold leading-[1.05] sm:text-6xl md:text-7xl"
            style={{ perspective: 800 }}
          >
            {name.map((char, i) => (
              <span key={i} className="hero-letter gold-gradient-text inline-block">
                {char}
              </span>
            ))}
          </h1>

          <div className="mt-4 h-10 text-xl font-medium text-[var(--color-gray)] sm:text-2xl">
            <span className="text-[var(--color-white)]">{typedRole}</span>
            <span className="ml-1 animate-pulse text-[var(--color-gold-accent)]">|</span>
          </div>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-6 max-w-xl text-base leading-relaxed text-[var(--color-gray)]"
          >
            Helping brands grow on Amazon and Shopify since 2019 — from product research
            to fulfillment — while building a foundation in cyber security and computer science.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.45 }}
            className="mt-9 flex flex-wrap gap-4"
          >
            <a href={profile.cvUrl} className="btn-gold" download>
              <Download size={16} /> Download CV
            </a>
            <a
              href="#contact"
              className="btn-outline"
              onClick={(e) => {
                e.preventDefault()
                document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })
              }}
            >
              <Mail size={16} /> Contact Me
            </a>
            <a
              href="#projects"
              className="btn-outline"
              onClick={(e) => {
                e.preventDefault()
                document.querySelector('#projects')?.scrollIntoView({ behavior: 'smooth' })
              }}
            >
              <FolderKanban size={16} /> View Projects
            </a>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.85, rotate: -4 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ duration: 0.9, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto hidden aspect-square w-full max-w-sm items-center justify-center lg:flex"
        >
          <div className="absolute inset-0 rounded-full border border-[#d4af37]/25" />
          <div className="absolute inset-6 rounded-full border border-[#d4af37]/15" />
          <div className="glass-card flex h-4/5 w-4/5 items-center justify-center rounded-full text-center">
            <div>
              <p className="font-display text-6xl font-bold gold-gradient-text">S</p>
              <p className="mt-2 text-xs uppercase tracking-[0.3em] text-[var(--color-gray)]">
                {profile.country}
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      <motion.a
        href="#about"
        onClick={(e) => {
          e.preventDefault()
          document.querySelector('#about')?.scrollIntoView({ behavior: 'smooth' })
        }}
        className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 text-[var(--color-gold-accent)]"
        animate={{ y: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 1.8, ease: 'easeInOut' }}
        aria-label="Scroll to About section"
      >
        <ArrowDown size={22} />
      </motion.a>
    </section>
  )
}
