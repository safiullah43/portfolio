import { motion, AnimatePresence } from 'framer-motion'

/**
 * Full-screen luxury loader: brand initials draw in, then the whole
 * screen wipes upward to reveal the site.
 */
export default function LoadingScreen({ isLoading }) {
  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#050505]"
          initial={{ opacity: 1 }}
          exit={{ y: '-100%' }}
          transition={{ duration: 0.9, ease: [0.76, 0, 0.24, 1] }}
        >
          <motion.div
            className="relative flex h-24 w-24 items-center justify-center rounded-full border border-[#d4af37]/30"
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            <motion.span
              className="font-display text-3xl font-bold gold-gradient-text"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              S
            </motion.span>
            <motion.svg
              className="absolute inset-0 h-full w-full -rotate-90"
              viewBox="0 0 100 100"
            >
              <motion.circle
                cx="50"
                cy="50"
                r="47"
                fill="none"
                stroke="url(#loaderGradient)"
                strokeWidth="1.5"
                strokeLinecap="round"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 1.6, ease: 'easeInOut' }}
              />
              <defs>
                <linearGradient id="loaderGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#f5c542" />
                  <stop offset="100%" stopColor="#d4af37" />
                </linearGradient>
              </defs>
            </motion.svg>
          </motion.div>

          <motion.p
            className="mt-6 text-xs tracking-[0.4em] text-[#a0a0a0] uppercase"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
          >
            Safiullah
          </motion.p>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
