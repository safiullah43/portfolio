import { useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowUpRight } from 'lucide-react'
import SectionHeading from './SectionHeading'
import { projects } from '../utils/data'
import { useInView } from '../hooks/useInView'

export default function Projects() {
  const [ref, isInView] = useInView({ threshold: 0.1 })
  const categories = useMemo(() => ['All', ...new Set(projects.map((p) => p.category))], [])
  const [activeFilter, setActiveFilter] = useState('All')

  const filtered =
    activeFilter === 'All' ? projects : projects.filter((p) => p.category === activeFilter)

  return (
    <section id="projects" className="relative py-28">
      <div className="section-container">
        <SectionHeading
          eyebrow="Selected Work"
          title="Projects"
          description="A snapshot of the e-commerce, security, and marketing work I've delivered for myself and for clients."
        />

        <div ref={ref} className="mb-10 flex flex-wrap justify-center gap-3">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={`rounded-full border px-5 py-2 text-xs font-semibold uppercase tracking-wide transition-all ${
                activeFilter === cat
                  ? 'border-[#d4af37] bg-gradient-to-r from-[#f5c542] to-[#d4af37] text-[#050505]'
                  : 'border-white/10 text-[var(--color-gray)] hover:border-[#d4af37]/50 hover:text-[var(--color-white)]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <motion.div layout className="grid gap-6 sm:grid-cols-2">
          <AnimatePresence mode="popLayout">
            {filtered.map((project) => (
              <motion.article
                layout
                key={project.title}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: isInView ? 1 : 0, y: isInView ? 0 : 30 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                className="glass-card group relative overflow-hidden p-7"
              >
                <div className="mb-5 flex h-36 items-center justify-center rounded-xl bg-gradient-to-br from-[#f5c542]/10 to-transparent">
                  <span className="font-display text-4xl font-bold text-[#d4af37]/30 transition-transform duration-500 group-hover:scale-110">
                    {project.title.split(' ').map((w) => w[0]).join('').slice(0, 3)}
                  </span>
                </div>

                <div className="mb-2 flex items-center justify-between gap-2">
                  <h3 className="font-display text-lg font-semibold text-[var(--color-white)]">
                    {project.title}
                  </h3>
                  <ArrowUpRight
                    size={18}
                    className="shrink-0 text-[var(--color-gold-accent)] opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                  />
                </div>

                <p className="text-sm leading-relaxed text-[var(--color-gray)]">
                  {project.description}
                </p>

                <div className="mt-5 flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-white/5 px-3 py-1 text-[11px] font-medium text-[var(--color-gray)]"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  )
}
