import { motion } from 'framer-motion'
import { fadeUp } from '../utils/motionVariants'
import { useInView } from '../hooks/useInView'

export default function SectionHeading({ eyebrow, title, description, align = 'center' }) {
  const [ref, isInView] = useInView({ threshold: 0.3 })

  return (
    <div
      ref={ref}
      className={`mb-14 flex flex-col ${align === 'center' ? 'items-center text-center' : 'items-start text-left'}`}
    >
      <motion.span
        custom={0}
        variants={fadeUp}
        initial="hidden"
        animate={isInView ? 'visible' : 'hidden'}
        className="section-eyebrow"
      >
        {eyebrow}
      </motion.span>
      <motion.h2
        custom={1}
        variants={fadeUp}
        initial="hidden"
        animate={isInView ? 'visible' : 'hidden'}
        className="section-title mt-3"
      >
        {title}
      </motion.h2>
      <motion.div
        custom={2}
        variants={fadeUp}
        initial="hidden"
        animate={isInView ? 'visible' : 'hidden'}
        className="divider-gold mt-5"
      />
      {description && (
        <motion.p
          custom={3}
          variants={fadeUp}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="mt-5 max-w-2xl text-sm leading-relaxed text-[var(--color-gray)] sm:text-base"
        >
          {description}
        </motion.p>
      )}
    </div>
  )
}
