import { useRef } from 'react'
import { motion } from 'framer-motion'
import {
  ShoppingBag, Search, Award, Store, Repeat, Truck,
  ShoppingCart, Handshake, Boxes, ShieldCheck, Megaphone,
} from 'lucide-react'
import SectionHeading from './SectionHeading'
import { services } from '../utils/data'
import { fadeUp, staggerContainer } from '../utils/motionVariants'
import { useInView } from '../hooks/useInView'

const icons = [ShoppingBag, Search, Award, Store, Repeat, Truck, ShoppingCart, Handshake, Boxes, ShieldCheck, Megaphone]

function ServiceCard({ service, Icon, index }) {
  const cardRef = useRef(null)

  function handleMouseMove(e) {
    const card = cardRef.current
    if (!card) return
    const rect = card.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    const rotateX = ((y - rect.height / 2) / rect.height) * -8
    const rotateY = ((x - rect.width / 2) / rect.width) * 8
    card.style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`
  }

  function handleMouseLeave() {
    if (cardRef.current) {
      cardRef.current.style.transform = 'perspective(700px) rotateX(0) rotateY(0) translateY(0)'
    }
  }

  return (
    <motion.div
      custom={index}
      variants={fadeUp}
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="glass-card p-7 transition-transform duration-300 will-change-transform"
    >
      <div className="mb-5 grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-[#f5c542]/20 to-[#d4af37]/10 text-[var(--color-gold-accent)]">
        <Icon size={22} />
      </div>
      <h3 className="mb-2 font-display text-lg font-semibold text-[var(--color-white)]">
        {service.title}
      </h3>
      <p className="text-sm leading-relaxed text-[var(--color-gray)]">{service.description}</p>
    </motion.div>
  )
}

export default function Services() {
  const [ref, isInView] = useInView({ threshold: 0.1 })

  return (
    <section id="services" className="relative py-28">
      <div className="section-container">
        <SectionHeading
          eyebrow="How I Can Help"
          title="Services"
          description="From account setup to full-scale growth strategy — practical, hands-on support across the Amazon and Shopify ecosystem."
        />

        <motion.div
          ref={ref}
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
        >
          {services.map((service, i) => (
            <ServiceCard key={service.title} service={service} Icon={icons[i % icons.length]} index={i} />
          ))}
        </motion.div>
      </div>
    </section>
  )
}
