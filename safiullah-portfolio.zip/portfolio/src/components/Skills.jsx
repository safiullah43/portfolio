import { motion } from 'framer-motion'
import SectionHeading from './SectionHeading'
import { skills } from '../utils/data'
import { fadeUp, staggerContainer } from '../utils/motionVariants'
import { useInView } from '../hooks/useInView'

const categories = ['E-Commerce', 'Marketing', 'Security', 'Soft Skills']

function SkillBar({ skill, isInView, index }) {
  return (
    <motion.div custom={index} variants={fadeUp}>
      <div className="mb-2 flex items-center justify-between text-sm">
        <span className="font-medium text-[var(--color-white)]">{skill.name}</span>
        <span className="text-[var(--color-gold-accent)]">{skill.level}%</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
        <motion.div
          className="h-full rounded-full bg-gradient-to-r from-[#f5c542] to-[#d4af37]"
          initial={{ width: 0 }}
          animate={{ width: isInView ? `${skill.level}%` : 0 }}
          transition={{ duration: 1.1, delay: index * 0.05, ease: [0.22, 1, 0.36, 1] }}
        />
      </div>
    </motion.div>
  )
}

export default function Skills() {
  const [ref, isInView] = useInView({ threshold: 0.1 })

  return (
    <section id="skills" className="relative py-28">
      <div className="section-container">
        <SectionHeading
          eyebrow="What I Bring"
          title="Skills & Expertise"
          description="A blend of e-commerce operations, digital marketing, cyber security fundamentals, and the soft skills that keep projects moving."
        />

        <div ref={ref} className="grid gap-10 sm:grid-cols-2">
          {categories.map((category, ci) => (
            <motion.div
              key={category}
              variants={staggerContainer}
              initial="hidden"
              animate={isInView ? 'visible' : 'hidden'}
              className="glass-card p-6 sm:p-8"
            >
              <motion.h3
                custom={0}
                variants={fadeUp}
                className="mb-6 font-display text-lg font-semibold text-[var(--color-gold-accent)]"
              >
                {category}
              </motion.h3>
              <div className="flex flex-col gap-5">
                {skills
                  .filter((s) => s.category === category)
                  .map((skill, i) => (
                    <SkillBar key={skill.name} skill={skill} isInView={isInView} index={i + ci} />
                  ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
