import { motion } from 'framer-motion'
import { HeartHandshake } from 'lucide-react'
import SectionHeading from './SectionHeading'
import { volunteer } from '../utils/data'
import { fadeUp } from '../utils/motionVariants'
import { useInView } from '../hooks/useInView'

export default function Volunteer() {
  const [ref, isInView] = useInView({ threshold: 0.2 })

  return (
    <section id="volunteer" className="relative py-28">
      <div className="section-container">
        <SectionHeading eyebrow="Giving Back" title="Volunteer Work" />

        <div ref={ref} className="mx-auto max-w-3xl">
          {volunteer.map((item, i) => (
            <motion.div
              key={item.organization}
              custom={i}
              variants={fadeUp}
              initial="hidden"
              animate={isInView ? 'visible' : 'hidden'}
              className="glass-card flex flex-col gap-4 p-8 sm:flex-row sm:items-start"
            >
              <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-[#f5c542]/20 to-[#d4af37]/10 text-[var(--color-gold-accent)]">
                <HeartHandshake size={24} />
              </div>
              <div>
                <p className="font-display text-lg font-semibold text-[var(--color-white)]">
                  {item.role}
                </p>
                <p className="mt-1 text-sm font-medium text-[var(--color-gold-accent)]">
                  {item.organization}
                </p>
                <p className="mt-3 text-sm leading-relaxed text-[var(--color-gray)]">
                  {item.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
