import { useEffect, useState } from 'react'

/** Tracks the pointer's viewport coordinates for cursor/glow effects. */
export function useMousePosition() {
  const [position, setPosition] = useState({ x: -100, y: -100 })

  useEffect(() => {
    function handleMove(e) {
      setPosition({ x: e.clientX, y: e.clientY })
    }
    window.addEventListener('mousemove', handleMove)
    return () => window.removeEventListener('mousemove', handleMove)
  }, [])

  return position
}
