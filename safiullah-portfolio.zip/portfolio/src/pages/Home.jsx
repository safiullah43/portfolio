import Hero from '../components/Hero'
import About from '../components/About'
import Skills from '../components/Skills'
import Services from '../components/Services'
import Experience from '../components/Experience'
import Education from '../components/Education'
import Volunteer from '../components/Volunteer'
import Projects from '../components/Projects'
import Achievements from '../components/Achievements'
import Contact from '../components/Contact'

export default function Home() {
  return (
    <>
      <Hero />
      <About />
      <Skills />
      <Services />
      <Experience />
      <Education />
      <Volunteer />
      <Projects />
      <Achievements />
      <Contact />
    </>
  )
}
