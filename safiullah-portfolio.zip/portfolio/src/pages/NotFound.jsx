import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Home as HomeIcon } from 'lucide-react'
import ParticlesBackground from '../components/ParticlesBackground'

export default function NotFound() {
  return (
    <section className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 text-center">
      <div className="absolute inset-0">
        <ParticlesBackground density={50} />
      </div>

      <motion.p
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="relative z-10 font-display text-[7rem] font-extrabold leading-none gold-gradient-text sm:text-[10rem]"
      >
        404
      </motion.p>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.15 }}
        className="relative z-10 mt-2 font-display text-2xl font-semibold text-[var(--color-white)] sm:text-3xl"
      >
        This page took a wrong turn.
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.25 }}
        className="relative z-10 mt-3 max-w-md text-sm text-[var(--color-gray)]"
      >
        The page you're looking for doesn't exist or has been moved. Let's get you back on track.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.35 }}
        className="relative z-10 mt-8"
      >
        <Link to="/" className="btn-gold">
          <HomeIcon size={16} /> Back to Home
        </Link>
      </motion.div>
    </section>
  )
}
