// Central content source for the portfolio.
// Swap placeholder links/details here without touching any component.

export const profile = {
  name: 'Safiullah',
  roles: [
    'Amazon Virtual Assistant',
    'E-Commerce Specialist',
    'Cyber Security Enthusiast',
    'BSCS Student',
  ],
  country: 'Pakistan',
  summary:
    'I am a freelance Amazon Virtual Assistant with professional experience since 2019. I specialize in Amazon FBA, Private Label, Wholesale, Online Arbitrage, Dropshipping, 3PL, Supplier Sourcing, Product Research, Inventory Management, Product Listings, and Shopify Store Management. I am currently pursuing a Bachelor of Computer Science (BSCS) and have completed a 4-Month Advanced Cyber Security Diploma. I am passionate about technology, cybersecurity, digital business, entrepreneurship, freelancing, artificial intelligence, and community development.',
  cvUrl: '#', // Replace with a real hosted CV file path
}

export const stats = [
  { label: 'Years of Experience', value: 5, suffix: '+' },
  { label: 'Specializations', value: 10, suffix: '+' },
  { label: 'Client Satisfaction', value: 100, suffix: '%' },
  { label: 'Projects Delivered', value: 30, suffix: '+' },
]

export const skills = [
  { name: 'Amazon FBA', level: 95, category: 'E-Commerce' },
  { name: 'Private Label', level: 90, category: 'E-Commerce' },
  { name: 'Wholesale', level: 88, category: 'E-Commerce' },
  { name: 'Online Arbitrage', level: 90, category: 'E-Commerce' },
  { name: 'Dropshipping', level: 85, category: 'E-Commerce' },
  { name: '3PL', level: 82, category: 'E-Commerce' },
  { name: 'Shopify', level: 87, category: 'E-Commerce' },
  { name: 'Supplier Sourcing', level: 90, category: 'E-Commerce' },
  { name: 'Inventory Management', level: 88, category: 'E-Commerce' },
  { name: 'Product Research', level: 92, category: 'E-Commerce' },
  { name: 'Digital Marketing', level: 78, category: 'Marketing' },
  { name: 'Graphic Design', level: 70, category: 'Marketing' },
  { name: 'Video Editing', level: 68, category: 'Marketing' },
  { name: 'Cyber Security', level: 75, category: 'Security' },
  { name: 'Network Security', level: 70, category: 'Security' },
  { name: 'Ethical Hacking Fundamentals', level: 65, category: 'Security' },
  { name: 'Problem Solving', level: 95, category: 'Soft Skills' },
  { name: 'Leadership', level: 88, category: 'Soft Skills' },
  { name: 'Communication', level: 92, category: 'Soft Skills' },
]

export const services = [
  {
    title: 'Amazon Account Management',
    description: 'End-to-end management of Amazon seller accounts, health monitoring, and performance optimization.',
  },
  {
    title: 'Amazon Product Hunting',
    description: 'Data-driven product research to uncover profitable, low-competition opportunities.',
  },
  {
    title: 'Private Label Consultation',
    description: 'Guidance on building and scaling your own private label brand on Amazon.',
  },
  {
    title: 'Wholesale Business',
    description: 'Sourcing and scaling wholesale accounts with reliable, vetted suppliers.',
  },
  {
    title: 'Online Arbitrage',
    description: 'Identifying high-margin retail and online arbitrage deals across multiple marketplaces.',
  },
  {
    title: 'Dropshipping',
    description: 'Setting up and running lean, automated dropshipping operations.',
  },
  {
    title: 'Shopify Management',
    description: 'Full Shopify store setup, theme customization, and ongoing store management.',
  },
  {
    title: 'Supplier Sourcing',
    description: 'Vetting and negotiating with domestic and overseas suppliers and manufacturers.',
  },
  {
    title: 'Inventory Management',
    description: 'Forecasting, replenishment planning, and stranded/aged inventory control.',
  },
  {
    title: 'Cyber Security Consultation',
    description: 'Foundational security guidance to protect your business accounts and digital assets.',
  },
  {
    title: 'Digital Marketing',
    description: 'Marketing support across listings, PPC fundamentals, and organic growth strategy.',
  },
]

export const experience = [
  {
    role: 'Freelance Amazon Virtual Assistant',
    period: '2019 — Present',
    points: [
      'Amazon FBA',
      'Private Label',
      'Wholesale',
      'Online Arbitrage',
      'Dropshipping',
      '3PL',
      'Supplier Communication',
      'Inventory Management',
      'Product Listings',
      'Business Growth Strategy',
    ],
  },
]

export const education = [
  {
    title: 'Bachelor of Computer Science (BSCS)',
    status: 'Currently Enrolled',
  },
  {
    title: 'Advanced Cyber Security Diploma',
    status: '4-Month Program — Completed',
  },
]

export const certifications = [
  { title: 'Advanced Cyber Security Diploma', issuer: 'Certified Program', year: '4 Months' },
  { title: 'Amazon Virtual Assistant Training', issuer: 'Professional Training', year: 'Completed' },
  { title: 'Future Certification', issuer: 'Coming Soon', year: 'TBA', placeholder: true },
  { title: 'Future Certification', issuer: 'Coming Soon', year: 'TBA', placeholder: true },
]

export const volunteer = [
  {
    organization: 'Environmental Protection Organization (EPO), Bhakkar',
    role: 'Flood Relief Volunteer',
    description:
      'Participated in humanitarian flood relief operations by distributing clean drinking water, food, and essential supplies to flood-affected communities. Worked collaboratively with volunteers to support relief efforts and community welfare.',
  },
]

export const projects = [
  {
    title: 'Amazon Business Management',
    category: 'E-Commerce',
    description: 'Complete Amazon seller account management including FBA, listings, and inventory strategy.',
    tags: ['Amazon FBA', 'Private Label', 'Wholesale'],
  },
  {
    title: 'Shopify Store Optimization',
    category: 'E-Commerce',
    description: 'Store setup, theme customization, and conversion-focused optimization for a Shopify brand.',
    tags: ['Shopify', 'Dropshipping', 'CRO'],
  },
  {
    title: 'Cyber Security Learning Projects',
    category: 'Security',
    description: 'Applied coursework from the Advanced Cyber Security Diploma covering network fundamentals and ethical hacking basics.',
    tags: ['Network Security', 'Ethical Hacking'],
  },
  {
    title: 'Digital Marketing Portfolio',
    category: 'Marketing',
    description: 'A collection of digital marketing campaigns and creative assets built for e-commerce clients.',
    tags: ['Digital Marketing', 'Graphic Design'],
  },
]

export const achievements = [
  { title: '5+ Years Freelancing', description: 'Continuous freelance Amazon VA experience since 2019.' },
  { title: 'Cyber Security Diploma', description: 'Completed a 4-month Advanced Cyber Security Diploma.' },
  { title: 'Community Service', description: 'Volunteered in flood relief operations with EPO Bhakkar.' },
  { title: 'Multi-Domain Specialist', description: 'Skilled across FBA, Private Label, Wholesale, Arbitrage, Dropshipping & 3PL.' },
]

export const contact = {
  email: 'your.email@example.com',
  linkedin: 'https://linkedin.com/in/your-profile',
  github: 'https://github.com/your-username',
  whatsapp: 'https://wa.me/00000000000',
  location: 'Pakistan',
}

export const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Services', href: '#services' },
  { label: 'Experience', href: '#experience' },
  { label: 'Projects', href: '#projects' },
  { label: 'Contact', href: '#contact' },
]
